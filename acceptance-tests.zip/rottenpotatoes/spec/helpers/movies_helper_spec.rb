require "rails_helper"

RSpec.describe MoviesHelper, :type => :helper do
  describe "#page_title" do
    it "returns the default title" do
      
    end
  end
end