require "rails_helper"

RSpec.describe "/index" do
  it "displays all the movies" do
    
  end
end